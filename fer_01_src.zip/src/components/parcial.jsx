/* eslint-disable react/prop-types */
import React from "react";

const Parcial = ({ id, nombre, peso, onEliminar }) => (
    <>
        <h3>{ nombre } - { peso } %</h3>
        <label>Nota<input type="number" /></label>
        <button onClick={ () => onEliminar(id) }>Eliminar</button>
    </>
);

export default Parcial;