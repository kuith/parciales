import React from 'react';
import Parcial from './parcial.jsx';

const Parciales = ({ parciales, onEliminarParcial }) => parciales.map(
    ({ id, nombre, peso }) => (
        <Parcial
            key={ id }
            id={ id }
            nombre={ nombre }
            peso={ peso }
            onEliminar={ onEliminarParcial }
        />
    )
);

export default Parciales;