import { Parcial } from './parcial.js';

let parciales = [];

const addParcial = data => {
    const parcial = new Parcial(data);
    parciales = [...parciales, parcial];
}

const removeParcial = id => {
    parciales = parciales.filter( parcial => parcial.id !== id);
}

const getParciales = () => [...parciales];

export const dataStorage = {
    addParcial,
    removeParcial,
    getParciales
}