export class Parcial {
    constructor({ nombre, peso }) {
        this.nombre = nombre;
        this.peso = peso;
        this.id = Date.now();
    }
}